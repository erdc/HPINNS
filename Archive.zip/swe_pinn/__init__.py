"""SWE PINN package."""
